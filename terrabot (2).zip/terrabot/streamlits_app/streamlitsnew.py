import streamlit as st
from PIL import Image
from ultralytics import YOLO
import numpy as np
import cv2

st.set_page_config(page_title="Terrabot - Detección de Plagas", layout="wide")

@st.cache_resource
def load_model():
    model = YOLO("best.pt")   
    return model

model = load_model()


st.markdown("""
<style>

    body, .stApp {
        background-color: #e8f5e9 !important;
    }

    .title {
        color: #1b5e20;
        text-align: center;
        font-size: 42px;
        font-weight: bold;
    }

    .subtitle {
        color: #2e7d32;
        text-align: center;
        font-size: 26px;
        margin-top: -10px;
    }

    .card {
        background-color: #d7f2dc;
        padding: 20px;
        border-radius: 12px;
        border: 2px solid #81c784;
        box-shadow: 0px 3px 10px rgba(0,0,0,0.1);
        text-align: center;
    }

    .plaga-card {
        background-color: #ffffff;
        border-left: 8px solid #2e7d32;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0px 3px 6px rgba(0,0,0,0.15);
    }

    .upload-box {
        border: 3px dashed #2e7d32;
        background-color: #f1f8f1;
        padding: 40px;
        border-radius: 12px;
        text-align: center;
        transition: 0.3s;
    }

    .upload-box:hover {
        background-color: #d4ebd8;
        border-color: #1b5e20;
    }

    .footer {
        text-align: center;
        color: #1b5e20;
        font-weight: bold;
        padding: 20px;
        margin-top: 40px;
    }

</style>
""", unsafe_allow_html=True)


st.markdown("<div class='title'>Terrabot</div>", unsafe_allow_html=True)
st.markdown("<div class='subtitle'>Detección de Plagas en Corona de Cristo</div>", unsafe_allow_html=True)
st.write("")


st.header("¿Cómo funciona?")
col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("""
    <div class='card'>
        <h3> Escanea el espécimen</h3>
        <p>Sube una fotografía de la planta mostrando síntomas de plagas.</p>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown("""
    <div class='card'>
        <h3> Análisis con IA</h3>
        <p>Un modelo entrenado detecta plagas automáticamente.</p>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown("""
    <div class='card'>
        <h3> Tratamiento sugerido</h3>
        <p>Recomendaciones según el tipo de plaga detectada.</p>
    </div>
    """, unsafe_allow_html=True)


st.header("Escaneo de Planta")

st.markdown("""
<div class='upload-box'>
    <h3>Sube una foto de tu planta</h3>
    <p>Haz clic para elegir un archivo o arrastra una imagen aquí.</p>
</div>
""", unsafe_allow_html=True)

uploaded_image = st.file_uploader(" ", type=["jpg", "jpeg", "png"])

if uploaded_image:
    image = Image.open(uploaded_image)
    img_np = np.array(image)

    st.image(image, caption="Imagen subida", use_column_width=True)

    st.success("Imagen cargada correctamente.")
    st.write("###  Analizando imagen con IA…")


    results = model(img_np)

    annotated = results[0].plot()  # Imagen con cajas dibujadas
    st.image(annotated, caption="Detecciones con IA", use_column_width=True)

    detections = results[0].boxes

    if len(detections) == 0:
        st.warning("No se detectaron plagas en la imagen.")
    else:
        st.success(f"Se detectaron {len(detections)} posibles plagas.")

        st.write("###  Plagas detectadas:")

        for box in detections:
            cls = int(box.cls[0])
            conf = float(box.conf[0])

            # Nombre de clase
            name = results[0].names[cls]

            st.write(f"- **{name}** (confianza: {conf:.2f})")

        # Tratamientos según clase
        st.write("###  Tratamiento sugerido:")

        if "cochinilla" in str(results[0].names).lower():
            st.write("- Alcohol isopropílico con algodón.")
        if "acaro" in str(results[0].names).lower():
            st.write("- Jabón potásico o acaricida.")
        if "pulgon" in str(results[0].names).lower():
            st.write("- Aceite de neem.")
        if "hongo" in str(results[0].names).lower():
            st.write("- Aplicar fungicida.")


st.header("Plagas comunes en Corona de Cristo")

colA, colB, colC, colD = st.columns(4)

with colA:
    st.markdown("""
    <div class='plaga-card'>
        <h4>Ácaros</h4>
        <p>Telarañas finas y hojas amarillentas.</p>
        <b>Tratamiento:</b> Jabón potásico
    </div>
    """, unsafe_allow_html=True)

with colB:
    st.markdown("""
    <div class='plaga-card'>
        <h4>Cochinillas</h4>
        <p>Insectos blancos y algodonosos.</p>
        <b>Tratamiento:</b> Alcohol isopropílico
    </div>
    """, unsafe_allow_html=True)

with colC:
    st.markdown("""
    <div class='plaga-card'>
        <h4>Pulgones</h4>
        <p>Insectos verdes o negros que chupan savia.</p>
        <b>Tratamiento:</b> Aceite de neem
    </div>
    """, unsafe_allow_html=True)

with colD:
    st.markdown("""
    <div class='plaga-card'>
        <h4>Hongos</h4>
        <p>Manchas blancas o anaranjadas.</p>
        <b>Tratamiento:</b> Fungicida
    </div>
    """, unsafe_allow_html=True)


st.markdown("""
<div class='footer'>
    Terrabot  2025 – Detección de Plagas con IA
</div>
""", unsafe_allow_html=True)
